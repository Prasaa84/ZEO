<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

    <h1>Your Registration is successful!</h1>

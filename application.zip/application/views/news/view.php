<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<?php
	echo '<h2>'.$news_item['title'].'</h2>';
	echo $news_item['text'];

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GeneralInfo extends CI_Controller {

	public function __construct(){
		parent::__construct();
		//$this->load->helper('url_helper');
	}
	public function contact(){
            $data['title'] = 'Contact Us';
	      $data['content'] = 'general_info/contact';
            $this->load->view('templates/template', $data);
	}
      public function aboutUs(){
            $data['title'] = 'About Us';
            $data['content'] = 'general_info/about_us';
            $this->load->view('templates/template', $data);
      }
      public function kotapolaDiv(){
            $data['title'] = 'Kotapola education division';
            $data['content'] = 'general_info/kotapola_div';
            $this->load->view('templates/template', $data);
      }
      public function morawakaDiv(){
            $data['title'] = 'Morawaka education division';
            $data['content'] = 'general_info/morawaka_div';
            $this->load->view('templates/template', $data);
      }
      public function pasgodaDiv(){
            $data['title'] = 'Pasgoda education division';
            $data['content'] = 'general_info/pasgoda_div';
            $this->load->view('templates/template', $data);
      }
      public function director(){
            $data['title'] = 'Zonal Education Director';
            $data['content'] = 'general_info/director';
            $this->load->view('templates/template', $data);
      }
      public function assDirectors(){
            $data['title'] = 'Assistant Education Directors';
            $data['content'] = 'general_info/ass_directors';
            $this->load->view('templates/template', $data);
      }
      public function divDirectors(){
            $data['title'] = 'Divisional Education Directors';
            $data['content'] = 'general_info/div_directors';
            $this->load->view('templates/template', $data);
      }
      public function adminOfficer(){
            $data['title'] = 'Administrative Officer';
            $data['content'] = 'general_info/admin_officer';
            $this->load->view('templates/template', $data);
      }
      public function accountant(){
            $data['title'] = 'Accountant';
            $data['content'] = 'general_info/accountant';
            $this->load->view('templates/template', $data);
      }
      public function otherStaff(){
            $data['title'] = 'Other Staff';
            $data['content'] = 'general_info/other_staff';
            $this->load->view('templates/template', $data);
      }
      public function loginPage(){
            $data['title'] = 'User Login Window';
            $data['content'] = 'general_info/login';
            $this->load->view('templates/template', $data);
      }
      public function gallery(){
            $data['title'] = 'Gallery';
            $data['content'] = 'general_info/gallery';
            $this->load->view('templates/template', $data);
      }
      public function news(){
            $data['title'] = 'News';
            $data['content'] = 'general_info/news';
            $this->load->view('templates/template', $data);
      }
}
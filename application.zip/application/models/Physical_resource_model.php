<?php
class Physical_resource_model extends CI_Model{

        public function __construct(){
            parent::__construct();
        }

        function add_new_item($data){
            $this->db->insert('physical_res_category_tbl', $data);
            if($this->db->affected_rows()>0){
                return true;
            }else{
                return false;
            }
        }

        function view_item_by_id($id){
            $condition = "phy_res_cat_id='".$id."' ";
            $this->db->select('*');
            $this->db->from('physical_res_category_tbl');
            $this->db->where($condition);
            $this->db->limit(1);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return false;
            }
        }
        
        public function view_all_items(){
            $this->db->select('*');
            $this->db->from('physical_res_category_tbl');
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return false;
            }
        }

        // this is called by view_recent_item_update_dt() in PhysicalResource controller
        // to view the date/time of recent updation
        function view_recent_item_update_dt(){
            $this->db->select('*');
            $this->db->from('physical_res_category_tbl');
            $this->db->limit(1);
            $this->db->order_by("date_updated","DESC");
            $query = $this->db->get();
            if($query->num_rows() > 0){
                return $query->result_array();
            } else {
                return false;
            }
        }

        function update_item($data){
            $item_id = $data['phy_res_cat_id'];
            $this->db->where('phy_res_cat_id',$item_id);
            $this->db->update('physical_res_category_tbl',$data); 
            if($this->db->affected_rows() > 0){         
                return true; 
            }else{
                return false; 
            }
        }

        function delete_item($id){
            $this->db->where('phy_res_cat_id',$id);
            $this->db->delete('physical_res_category_tbl');
            if ($this->db->affected_rows() > 0) {
                return true;
            } else {
                return false;
            }
        }

        function add_new_status($data){
            $this->db->insert('physical_res_status_tbl', $data);
            if($this->db->affected_rows()>0){
                return true;
            }else{
                return false;
            }        
        }
        
        public function view_all_status(){
            $this->db->select('*');
            $this->db->from('physical_res_status_tbl');
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return false;
            }
        }

        function view_status_by_id($id){
            $condition = "phy_res_status_id='".$id."' ";
            $this->db->select('*');
            $this->db->from('physical_res_status_tbl');
            $this->db->where($condition);
            $this->db->limit(1);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return false;
            }
        }
        // ajax call to view status in addphysicalresourcepage
        function view_status_by_condition($condition){
            $this->db->select('*');
            $this->db->from('physical_res_status_tbl');
            $this->db->where($condition);
            $query = $this->db->get();
            return $query->result();
        }

        function update_status($data){
            $status_id = $data['phy_res_status_id'];
            $this->db->where('phy_res_status_id',$status_id);
            $this->db->update('physical_res_status_tbl',$data); 
            if($this->db->affected_rows() > 0){         
                return true; 
            }else{
                return false; 
            }
        }

        function view_recent_status_update_dt(){
            $this->db->select('*');
            $this->db->from('physical_res_status_tbl');
            $this->db->limit(1);
            $this->db->order_by("date_updated","DESC");
            $query = $this->db->get();
            if($query->num_rows() > 0){
                return $query->result_array();
            } else {
                return false;
            }
        }

        function delete_status($id){
            $this->db->where('phy_res_status_id',$id);
            $this->db->delete('physical_res_status_tbl');
            if ($this->db->affected_rows() > 0) {
                return true;
            } else {
                return false;
            }
        }

        function check_item_status_details_exists($census_id,$item_id){
            $condition = "census_id = $census_id and phy_res_cat_id = $item_id";
            $this->db->select('*');
            $this->db->from('physical_res_details_tbl');
            $this->db->where($condition);
            $query = $this->db->get();
            if($query->num_rows() > 0){
                return $query->result();
            } else {
                return false;
            }
        }

        function add_new_phy_res_details($data){
            $this->db->insert('physical_res_details_tbl', $data);
            if($this->db->affected_rows()>0){
                return true;
            }else{
                return false;
            }        
        }

        function view_recent_item_status_update_dt($data){
            $condition = $data;
            $this->db->select('*');
            $this->db->from('physical_res_details_tbl');
            $this->db->where($condition);
            $this->db->limit(1);
            $this->db->order_by("date_updated","DESC");
            $query = $this->db->get();
            if($query->num_rows() > 0){
                return $query->result();
            } else {
                return false;
            }
        }

        function view_item_status_by_census_id($census_id){
            $this->db->select('*');
            $this->db->from('physical_res_details_tbl');
            $this->db->join('school_details_tbl','physical_res_details_tbl.census_id = school_details_tbl.census_id');
            $this->db->join('physical_res_category_tbl','physical_res_details_tbl.phy_res_cat_id = physical_res_category_tbl.phy_res_cat_id','left');
            $this->db->join('physical_res_status_tbl','physical_res_details_tbl.phy_res_status_id = physical_res_status_tbl.phy_res_status_id','left');
            $this->db->where('physical_res_details_tbl.census_id',$census_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return false;
            }  
        }

        function get_logged_school_phy_res_info($userid){
            $this->db->select('*');
            $this->db->from('physical_res_details_tbl');
            $this->db->join('school_details_tbl','physical_res_details_tbl.census_id = school_details_tbl.census_id');
            $this->db->join('physical_res_category_tbl','physical_res_details_tbl.phy_res_cat_id = physical_res_category_tbl.phy_res_cat_id');
            $this->db->join('physical_res_status_tbl','physical_res_details_tbl.phy_res_status_id = physical_res_status_tbl.phy_res_status_id');
            $this->db->where('physical_res_details_tbl.census_id',$census_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return false;
            }   
        }

        function view_item_status_details_by_id($id){ // according physical resource details id 
            $this->db->select('*,physical_res_details_tbl.date_added as details_date_added,physical_res_details_tbl.date_updated as details_date_updated');
            $this->db->from('physical_res_details_tbl');
            $this->db->join('school_details_tbl','physical_res_details_tbl.census_id = school_details_tbl.census_id');
            $this->db->join('physical_res_category_tbl','physical_res_details_tbl.phy_res_cat_id = physical_res_category_tbl.phy_res_cat_id');
            $this->db->join('physical_res_status_tbl','physical_res_details_tbl.phy_res_status_id = physical_res_status_tbl.phy_res_status_id','left');
            $this->db->where('physical_res_details_tbl.phy_res_detail_id',$id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return false;
            }  
        }
        function view_item_status_details_all_schools(){ // all schools physical resource details
            $this->db->select('*,physical_res_details_tbl.date_updated as details_date_updated,school_details_tbl.census_id,school_details_tbl.sch_type_id');
            $this->db->from('physical_res_details_tbl');
            $this->db->join('school_details_tbl','physical_res_details_tbl.census_id = school_details_tbl.census_id');
            $this->db->join('physical_res_category_tbl','physical_res_details_tbl.phy_res_cat_id = physical_res_category_tbl.phy_res_cat_id');
            $this->db->join('physical_res_status_tbl','physical_res_details_tbl.phy_res_status_id = physical_res_status_tbl.phy_res_status_id');
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return false;
            }  
        }
        // following method shows schools according to item status
        function view_schools_by_item_status($cat_id,$status_id){
            $this->db->select('*,physical_res_details_tbl.date_added as details_date_added,physical_res_details_tbl.date_updated as details_date_updated,school_type_tbl.sch_type');
            $this->db->from('physical_res_details_tbl');
            $this->db->join('school_details_tbl','physical_res_details_tbl.census_id = school_details_tbl.census_id');
            $this->db->join('physical_res_category_tbl','physical_res_details_tbl.phy_res_cat_id = physical_res_category_tbl.phy_res_cat_id');
            $this->db->join('physical_res_status_tbl','physical_res_details_tbl.phy_res_status_id = physical_res_status_tbl.phy_res_status_id');
            $this->db->join('school_type_tbl','school_details_tbl.sch_type_id = school_type_tbl.sch_type_id');
            $this->db->join('edu_devision_tbl','school_details_tbl.edu_div_id = edu_devision_tbl.edu_div_id');
            $this->db->where('physical_res_details_tbl.phy_res_cat_id',$cat_id)->where('physical_res_details_tbl.phy_res_status_id',$status_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return false;
            }  
        }
        // following method counts schools according to item status
        function count_sch_by_phy_res_status($cat_id,$status_id){
            $this->db->select('count(*) as count,physical_res_details_tbl.date_updated as details_date_updated');
            $this->db->from('physical_res_details_tbl');
            $this->db->join('school_details_tbl','physical_res_details_tbl.census_id = school_details_tbl.census_id');
            $this->db->join('physical_res_category_tbl','physical_res_details_tbl.phy_res_cat_id = physical_res_category_tbl.phy_res_cat_id');
            $this->db->join('physical_res_status_tbl','physical_res_details_tbl.phy_res_status_id = physical_res_status_tbl.phy_res_status_id');
            $this->db->join('school_type_tbl','school_details_tbl.sch_type_id = school_type_tbl.sch_type_id');
            $this->db->join('edu_devision_tbl','school_details_tbl.edu_div_id = edu_devision_tbl.edu_div_id');
            $this->db->where('physical_res_details_tbl.phy_res_cat_id',$cat_id)->where('physical_res_details_tbl.phy_res_status_id',$status_id);
            $this->db->group_by(array("physical_res_details_tbl.phy_res_cat_id", "physical_res_details_tbl.phy_res_status_id"));
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return false;
            }  
        }
        function update_item_status_details($data){
            //print_r($data); die();
            //$condition = "phy_res_cat_id = ".$data['phy_res_cat_id'];
            $phy_res_detail_id = $data['phy_res_detail_id'];
            //echo $item_id; die();
            $this->db->where('phy_res_detail_id',$phy_res_detail_id);
            $this->db->update('physical_res_details_tbl',$data); 
            if($this->db->affected_rows() > 0){         
                return true; 
            }else{
                return false; 
            }
        }

    function delete_item_status_details($id){
        $this->db->where('phy_res_detail_id',$id);
        $this->db->delete('physical_res_details_tbl');
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    // used for header notifications
    function get_short_phy_res_details($census_id){
        $items = $this->get_count_all_phy_res_items(); // get number of items
        if($items){
            $this->db->select('*');
            $this->db->from('physical_res_details_tbl');
            $this->db->where('physical_res_details_tbl.census_id',$census_id);
            $query = $this->db->get();
            $details = $query->num_rows();
            if($details < $items) {
                // every school must have physical resource details equal to number of items
                // other wise difference must be shown as a notification
                return $items - $details;
            } else {
                return false;
            }   
        }
    }
    // used for header notifications
    function get_count_all_phy_res_items(){
        $this->db->select('*');
        $this->db->from('physical_res_category_tbl');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        } else {
            return false;
        }

    }
}